import { resolveChannelFromLink } from '../../libs/newsletter-link.js';

const handler = async (m, { conn, text }) => {
    if (!text?.trim()) return m.reply('⚠️ ابعت رابط قناة واتساب بالشكل ده:\nhttps://whatsapp.com/channel/كود_الدعوة');

    try {
        const { jid, url, result, metadata: meta } = await resolveChannelFromLink(conn, text);
        const name = meta?.name?.text || meta?.name || 'مش معروف';
        const desc = meta?.description?.text || meta?.description || 'مفيش وصف';
        const subs = meta?.subscribers_count ?? 'غير متاح';
        const created = meta?.creation_time
            ? new Date(Number(meta.creation_time) * 1000).toLocaleString('ar-EG')
            : 'مش معروف';
        const status = result?.state?.type || 'مش معروف';
        const verify = meta?.verification || 'مش معروف';
        const img = meta?.preview?.direct_path
            ? `https://mmg.whatsapp.net${meta.preview.direct_path}`
            : undefined;

        const msg = `📢 *معلومات القناة*\n\n` +
            `👤 الاسم: ${name}\n👥 المشتركين: ${subs}\n` +
            `📅 تاريخ الإنشاء: ${created}\n📡 الحالة: ${status}\n` +
            `✔️ التوثيق: ${verify}\n\n📝 الوصف:\n${desc}\n\n` +
            `🔗 رابط القناة: ${url}`;

        // The user-facing action opens the actual invite URL; JID is not exposed as a join link.
        if (img) {
            await conn.sendMessage(m.chat, { image: { url: img }, caption: msg });
        } else {
            await conn.sendMessage(m.chat, { text: msg });
        }
        // WhatsApp turns the invite URL into a tappable link in chat.
        await conn.sendMessage(m.chat, { text: `🔗 افتح القناة من الرابط:
${url}` });
    } catch (e) {
        return m.reply(`❌ مقدرتش أتعرف على القناة من الرابط.\n${e?.message || 'تأكد من الرابط وحاول تاني.'}`);
    }
};

handler.command = ['قناة'];
handler.usage = ['قناة https://whatsapp.com/channel/...'];
export default handler;
