import { resolveChannelFromLink } from '../../libs/newsletter-link.js';

const isOwner = (m, bot) => bot?.config?.owners?.some(o => m.sender === o.jid || m.sender === o.lid);

const handler = async (m, { conn, text, bot }) => {
    if (!isOwner(m, bot)) return m.reply('❌ الأمر ده للمطورين بس.');
    const [url, ...content] = String(text || '').split('|');
    const message = content.join('|').trim();
    if (!url?.trim() || !message) {
        return m.reply('الاستخدام:\n.نشر_بالقناة https://whatsapp.com/channel/... | النص المراد نشره');
    }
    try {
        const { jid, url: canonicalUrl } = await resolveChannelFromLink(conn, url.trim());
        await conn.sendMessage(jid, { text: message });
        return m.reply(`✅ تم إرسال المنشور للقناة:\n${canonicalUrl}`);
    } catch (e) {
        return m.reply(`❌ فشل النشر. تأكد من رابط القناة وصلاحية البوت.\n${e?.message || ''}`);
    }
};

handler.usage = ['نشر_بالقناة رابط_القناة | النص'];
handler.category = 'settings';
handler.command = ['نشر_بالقناة'];
handler.owner = true;
handler.cooldown = 3000;
export default handler;
