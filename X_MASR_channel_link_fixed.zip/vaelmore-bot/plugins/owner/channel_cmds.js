import { resolveChannelFromLink } from '../../libs/newsletter-link.js';

const handler = async (m, { conn, command, text }) => {
    const input = String(text || '').trim();

    if (command === 'انضم_القناة' || command === 'join_channel') {
        if (!input) return m.reply('⚠️ ابعت رابط القناة:\nhttps://whatsapp.com/channel/...');
        try {
            const { jid, url, metadata } = await resolveChannelFromLink(conn, input);
            await conn.newsletterFollow(jid);
            global.__VAELMORE_CHANNEL = { jid, url, name: metadata?.name?.text || metadata?.name || '' };
            return m.reply(`✅ تم طلب متابعة القناة بنجاح.\n📢 ${global.__VAELMORE_CHANNEL.name || 'القناة'}\n🔗 ${url}`);
        } catch (e) {
            return m.reply(`❌ فشل التعرف على القناة أو متابعتها.\n${e?.message || 'تأكد من الرابط.'}`);
        }
    }

    if (command === 'تفاعل_القناة' || command === 'channel_react') {
        const [action, ...urlParts] = input.split(/\s+/);
        const url = urlParts.join(' ');
        if (!['on', 'تشغيل', 'off', 'ايقاف'].includes(action?.toLowerCase())) {
            return m.reply('الاستخدام:\n.تفاعل_القناة تشغيل https://whatsapp.com/channel/...\n.تفاعل_القناة ايقاف https://whatsapp.com/channel/...');
        }
        if (!url) return m.reply('⚠️ لازم تبعت رابط القناة مع الأمر؛ مفيش معرّف افتراضي.');
        try {
            const { jid, url: canonicalUrl } = await resolveChannelFromLink(conn, url);
            if (!global._channelReact) global._channelReact = {};
            if (['on', 'تشغيل'].includes(action.toLowerCase())) {
                global._channelReact[jid] = true;
                global.__VAELMORE_CHANNEL = { ...(global.__VAELMORE_CHANNEL || {}), jid, url: canonicalUrl };
                return m.reply(`✅ التفاعل اتفعل للقناة دي:\n${canonicalUrl}`);
            }
            delete global._channelReact[jid];
            return m.reply(`🛑 التفاعل اتوقف للقناة دي:\n${canonicalUrl}`);
        } catch (e) {
            return m.reply(`❌ مقدرتش أتعرف على القناة من الرابط.\n${e?.message || ''}`);
        }
    }
};

handler.command = ['انضم_القناة', 'join_channel', 'تفاعل_القناة', 'channel_react'];
handler.usage = ['انضم_القناة رابط_القناة', 'تفاعل_القناة تشغيل/ايقاف رابط_القناة'];
handler.owner = true;
handler.category = 'settings';
export default handler;
