import { resolveChannelFromLink } from '../../libs/newsletter-link.js';

const handler = async (m, { conn, bot, command, text }) => {
    const owners = (bot.config?.owners || []).flatMap(o => [o.jid, o.lid]).filter(Boolean);
    if (!owners.includes(m.sender) && !m.isOwner) return m.reply('❌ الأمر ده للمطورين بس.');

    const url = String(text || '').trim();
    if (!url) return m.reply('ابعت رابط القناة مع الأمر:\n.تفاعل_تفعيل https://whatsapp.com/channel/...');

    try {
        const { jid, url: canonicalUrl } = await resolveChannelFromLink(conn, url);
        if (!global._channelReact) global._channelReact = {};
        if (command === 'تفاعل_تفعيل') {
            global._channelReact[jid] = true;
            return m.reply(`✅ التفاعل التلقائي اتفعل للقناة:\n${canonicalUrl}`);
        }
        delete global._channelReact[jid];
        return m.reply(`🛑 التفاعل التلقائي اتوقف للقناة:\n${canonicalUrl}`);
    } catch (e) {
        return m.reply(`❌ فشل التعرف على القناة من الرابط.\n${e?.message || ''}`);
    }
};

handler.command = ['تفاعل_تفعيل', 'تفاعل_ايقاف'];
handler.category = 'owner';
handler.usage = ['تفاعل_تفعيل رابط_القناة', 'تفاعل_ايقاف رابط_القناة'];
handler.owner = true;
export default handler;
