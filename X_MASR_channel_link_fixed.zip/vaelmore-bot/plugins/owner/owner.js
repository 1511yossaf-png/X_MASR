// أسامي المطورين وبياناتهم
const DEVS = {
    'يوسف x': { name: 'يوسف X', jid: '201122534233' },
    'youssef x': { name: 'يوسف X', jid: '201122534233' },
    'owner': { name: 'Owner', jid: '201223244336' },
};

let handler = async (m, { conn, bot, text, args, command }) => {
    // هات الاسم من text أو من body على طول (احتياطي للـ regex commands)
    let arg = (text || '').trim().toLowerCase();

    // لو text فاضي هجيب من body على طول (لو الـ regex أخد أول كلمة بس)
    if (!arg && m.body) {
        const body = m.body.trim();
        // اقطع الـ prefix + command وهات الباقي
        const parts = body.split(/\s+/);
        if (parts.length > 1) {
            arg = parts.slice(1).join(' ').toLowerCase();
        }
    }

    let watermark;
    let num;

    if (arg) {
        const dev = DEVS[arg];
        if (!dev) {
            const list = [...new Set(Object.values(DEVS).map(d => d.name))].join('\n');
            return m.reply(`*❌ المطور ده مش معروف عندنا*\n\n*الأسامي الموجودة:*\n${list}\n\n*مثال:* .مطور يوسف X`);
        }
        watermark = dev.name;
        num = dev.jid;
    } else {
        // من غير ما تكتب اسم - هيجيب كارت أول مطور في الـ owners
        watermark = bot?.config?.owners?.[0]?.name || 'يوسف X';
        num = bot?.config?.owners?.[0]?.jid?.split('@')[0] || '201122534233';
    }

    const quoted = {
        key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: 'status@broadcast' },
        message: { conversation: 'X MASR👨🏻‍💻🔥' }
    };

    const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${watermark}\nTEL;type=CELL;waid=${num}:+${num}\nEND:VCARD`;
    const img = 'https://i.postimg.cc/JntTcfnP/782d05642e3887d29ed37900aa767c6a.jpg';

    await conn.sendMessage(m.chat, {
        contacts: { displayName: watermark, contacts: [{ vcard }] },
        contextInfo: {
            forwardingScore: 2023,
            externalAdReply: {
                title: '𝑇𝛨𝛯 𝛩𝑊𝛮𝛯𝑅',
                body: watermark,
                sourceUrl: 'https://whatsapp.com/channel/0029VbEB391HwXb5SU8UH33K',
                thumbnailUrl: img,
                mediaType: 1,
                showAdAttribution: true,
                renderLargerThumbnail: true
            }
        }
    }, { quoted });
};

handler.command = /^(owner|مطور|المطور)$/i;

export default handler;
